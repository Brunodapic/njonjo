export const getAllUsers = (req, res) => {
    res.send('This is a GET /api/user route');
}