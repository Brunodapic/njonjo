## Pixion JSSchool 2023

[Lesson 1 - JavaScript](https://docs.google.com/presentation/d/1zyvTk4hDvKvCZaCyYufzLpxMvmDSZdSFZjAk2dw_Jqk/edit?usp=sharing)


[Lesson 2 - Node](https://docs.google.com/presentation/d/1ZiBg0bogI2RT0H-QjwRNxysL6WuLBX0dAqsVM_RL1eA/edit?usp=sharing)


[Lesson 3 - React](https://docs.google.com/presentation/d/1ytNZzPTi3NyiZzSukqN0AZO26CcFX-oLL7L4XBXzxb4/edit?usp=sharing)


[Lesson 4 - MERN](https://docs.google.com/presentation/d/1d1pFjPMK2Pcsuzl6eGL2Jx8AMPHsKKoNJUfgXXsYXEE/edit?usp=sharing)
